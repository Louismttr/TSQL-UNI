create database SVentas

use SVentas

CREATE TABLE [dbo].[Deptos](
	[Id_Depto] [int] IDENTITY(1,1) NOT NULL,
	[NombreDepto] [nvarchar](25) NOT NULL,
	[EstadoD] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Depto] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[Deptos] ADD  DEFAULT ((1)) FOR [EstadoD]

CREATE TABLE [dbo].[Municipios](
	[Id_Mun] [int] IDENTITY(1,1) NOT NULL,
	[NombreMun] [nvarchar](25) NOT NULL,
	[Id_Depto] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Mun] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[Municipios]  WITH CHECK ADD FOREIGN KEY([Id_Depto])
REFERENCES [dbo].[Deptos] ([Id_Depto])

CREATE TABLE [dbo].[Clientes](
	[CodCliente] [char](4) NOT NULL,
	[PNC] [nvarchar](15) NOT NULL,
	[SNC] [nvarchar](15) NULL,
	[PAC] [nvarchar](15) NOT NULL,
	[SAC] [nvarchar](15) NULL,
	[Cedula] [char](16) NULL,
	[DirC] [nvarchar](50) NOT NULL,
	[Id_Depto] [int] NOT NULL,
	[FNac] [char](10) NULL,
	[EstadoC] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[CodCliente] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[Proveedor](
	[RUC] [char](11) NOT NULL,
	[NombreProv] [nvarchar](40) NOT NULL,
	[DirProv] [nvarchar](50) NOT NULL,
	[Id_Depto] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[RUC] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[Proveedor]  WITH CHECK ADD FOREIGN KEY([Id_Depto])
REFERENCES [dbo].[Deptos] ([Id_Depto])

CREATE TABLE [dbo].[Productos](
	[CodProd] [char](5) NOT NULL,
	[NombreProd] [nvarchar](50) NOT NULL,
	[PrecioP] [money] NOT NULL,
	[ExistP] [int] NOT NULL,
	[RUC] [char](11) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[CodProd] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[Productos]  WITH CHECK ADD FOREIGN KEY([RUC])
REFERENCES [dbo].[Proveedor] ([RUC])

CREATE TABLE [dbo].[Ventas](
	[Id_Venta] [int] IDENTITY(1,1) NOT NULL,
	[FechaV] [date] NOT NULL,
	[CodCliente] [char](4) NOT NULL,
	[TotalV] [money] NULL,
	[EstadoV] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Venta] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[Ventas] ADD  DEFAULT ((1)) FOR [EstadoV]
ALTER TABLE [dbo].[Ventas] ADD  DEFAULT (getdate()) FOR [FechaV]


ALTER TABLE [dbo].[Ventas]  WITH CHECK ADD FOREIGN KEY([CodCliente])
REFERENCES [dbo].[Clientes] ([CodCliente])

CREATE TABLE [dbo].[Det_Ventas](
	[Id_Venta] [int] NOT NULL,
	[CodProd] [char](5) NOT NULL,
	[cantv] [int] NOT NULL,
	[stp] [money] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Venta] ASC,
	[CodProd] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[Det_Ventas]  WITH CHECK ADD FOREIGN KEY([CodProd])
REFERENCES [dbo].[Productos] ([CodProd])


ALTER TABLE [dbo].[Det_Ventas]  WITH CHECK ADD FOREIGN KEY([Id_Venta])
REFERENCES [dbo].[Ventas] ([Id_Venta])


CREATE TABLE [dbo].[Compras](
	[NFactC] [char](5) NOT NULL,
	[FechaC] [date] NOT NULL,
	[RUC] [char](11) NOT NULL,
	[TotalC] [money] NULL,
PRIMARY KEY CLUSTERED 
(
	[NFactC] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[Compras]  WITH CHECK ADD FOREIGN KEY([RUC])
REFERENCES [dbo].[Proveedor] ([RUC])


CREATE TABLE [dbo].[Det_Compras](
	[NFactC] [char](5) NOT NULL,
	[CodProd] [char](5) NOT NULL,
	[cantc] [int] NOT NULL,
	[precioc] [money] NOT NULL,
	[subtc] [money] NULL,
PRIMARY KEY CLUSTERED 
(
	[NFactC] ASC,
	[CodProd] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[Det_Compras]  WITH CHECK ADD FOREIGN KEY([CodProd])
REFERENCES [dbo].[Productos] ([CodProd])


ALTER TABLE [dbo].[Det_Compras]  WITH CHECK ADD FOREIGN KEY([NFactC])
REFERENCES [dbo].[Compras] ([NFactC])


insert into Deptos values ('Managua',1),('Masaya',1), ('Granada',1),('Leon',1), ('Chinandega',1)

select * from Deptos

alter table Municipios add EstadoMun bit default 1

insert into Municipios values('Managua',1,1),('Tipitapa',1,1),('Nindiri',2,1),('Catarina',2,1),
('Diria',3,1)

select * from Municipios

insert into Clientes values('01','Reynaldo','','Casta�o','Uma�a','001-311271-0012R','Ducuali',1,'1971-12-31',1),
('02','Yasser', 'Ronaldo','Membre�o','Gudiel','001-110681-0052J','Residencial Mayales',1,'1981-06-11',1)

select * from Clientes

alter table Proveedor add EstadoProv bit default 1

insert into Proveedor values('J01','Apple','Galeria Santo Domingo',1,1),('J02','La Curacao', 'Metrocentro',1,1),
('J03','Almacenes SIMAN','Galeria Santo Domingo',1,1)

select * from Proveedor

alter table Productos add EstadoProd bit default 1

insert into Productos values('01','Iphone 15 Pro',2500,5,'J01',1),('02','Iphone 15 pro max',2800,4,'J01',1)

select * from Productos





ALTER TABLE [dbo].[Clientes] ADD  DEFAULT ((1)) FOR [EstadoC]


ALTER TABLE [dbo].[Clientes]  WITH CHECK ADD FOREIGN KEY([Id_Depto])
REFERENCES [dbo].[Deptos] ([Id_Depto])


ALTER TABLE [dbo].[Clientes]  WITH CHECK ADD CHECK  (([Cedula] like '[0-9][0-9][0-9]-[0-9][0-9][0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9][A-Z]'))



create table DevCE(
IdDCE int identity(1,1) primary key not null,
FechaDCE datetime default getdate() not null,
CodCliente char(4) foreign key references Clientes(CodCLiente) not null,
TotalDC money
)


create table Det_DevCE(
IdDCE int foreign key references DevCE(IdDCE) not null,
CodProd char(5) foreign key references Productos(CodProd) not null,
cantdc int not null,
subtdc float,
primary key(IdDCE,CodProd)
)

create table DevEP(
IdDEP int identity(1,1) primary key not null,
FechaDEP datetime default getdate() not null,
CodCliente char(4) foreign key references Clientes(CodCLiente) not null,
TotalDP money
)


create table Det_DevEP(
IdDEP int foreign key references DevEP(IdDEP) not null,
CodProd char(5) foreign key references Productos(CodProd) not null,
cantdp int not null,
subtdp float,
primary key(IdDEP,CodProd)
)

--- CRUD, Ventas y productos

------ Ventas
--Insercion 
create procedure InsertVen
@IDV int,
@FechaV date,
@CodCli char(4),
@TotalV money,
@Estado bit
as
declare @idven as int
set @idven=(select Id_Venta from Ventas 
where Id_Venta=@IDV)
if(@IDV='' or @FechaV='' or @CodCli='' or @TotalV= '' )
begin
	print 'No pueden ser nulos'
end
else
begin
	if(@IDV=@idven)
	begin
		print 'Venta ya registrada con anterioridad'
	end
	else
		begin
			insert into Ventas values(@FechaV,@CodCli,
			@TotalV, 1)
	end
end
-- Procedimiento de Modificaci�n
alter procedure ModV
@IDV int,
@FechaV date,
@CodCli char(4),
@TotalV money,
@EstadoV bit
as declare @iv as int
set @iv=(select Id_Venta from Ventas where Id_Venta=@IDV)
if(@IDV='' or @CodCli='' or @TotalV='')
begin
	print 'No pueden ser nulos'
end
else
		begin
			update Ventas set
			FechaV=@FechaV, CodCliente=@CodCli
			where Id_Venta=@IDV and EstadoV=1
	end

-- Procedimiento de Dar baja
create procedure DarBV
@IDV int
as
declare @iv as int
set @iv=(select Id_Venta from Ventas 
where Id_Venta=@IDV)
if(@IDV=@iv)
begin
	update Ventas set EstadoV=0 where Id_Venta=@IDV
end
else
begin
	print 'Venta no encontrada'
end


select * from Ventas where EstadoV=0

--Buscar
create procedure BuscaV
@IDV int
as 
declare @iv as int
set @iv=(select Id_Venta from Ventas where Id_Venta=@IDV)
if(@IDV='')
begin
	print 'No puede ser nulo'
end
	else
	begin
		if(@IDv=@iv)
		begin
			select * from Ventas where Id_Venta=@IDV
		end
		else
		begin
			print 'Venta no encontrada'
		end
	end

	---Tabla temporal Ventas
CREATE TABLE TemVentas(
	Id_Venta int IDENTITY(1,1) NOT NULL,
	FechaV date NOT NULL,
	CodCliente char(4) NOT NULL,
	TotalV money NULL,
	EstadoV bit NULL
)
create TRIGGER StatusChangeTrigger
ON Ventas
AFTER UPDATE AS 

 SET IDENTITY_INSERT TemVentas ON
 IF UPDATE(EstadoV)
 BEGIN
		UPDATE Ventas SET EstadoV=0 WHERE Id_Venta=(SELECT Id_Venta FROM inserted);
 
    	INSERT INTO TemVentas () (SELECT Id_Venta, FechaV,CodCliente,TotalV,EstadoV FROM deleted WHERE Id_Venta=deleted.Id_Venta);
	
    END;

--Mostrar Productos
create proc MostrarV
as
BEGIN
     select Id_Venta as ID,FechaV as Fecha,CodCliente as CodCliente,TotalV as TotalV from Ventas where EstadoV=1
END   

---PRODUCTOS
InsertProduct '00001', 'Manzana', '30.5', '12', 'J03'
--Insercion 
create procedure InsertProduct
@CodP char(5)
,@NP nvarchar(50)
,@PrecioP money
,@ExistP int
,@RUC char(11)
as
declare @idp as char(4)
set @idp=(select CodProd from Productos
where CodProd=@CodP)
if(@CodP='' or @NP='' OR @PrecioP='' or @ExistP='' or @RUC='')
begin
	print 'No pueden ser nulos'
end
else
begin
	if(@CodP=@idp)
	begin
		print 'Producto ya registrado'
	end
	else
		begin
			insert into Productos values(@CodP, @NP,@PrecioP, @ExistP, @RUC,1)
	end
end
-- Procedimiento de Modificaci�n
create procedure ModProduct
@CodP char(5)
,@NP nvarchar(50)
,@PrecioP money
,@ExistP int
,@RUC char(11)
as declare @ip as char(5)
set @ip=(select CodProd from Productos where CodProd=@CodP)
if(@CodP='' or @NP='' OR @PrecioP='' or @ExistP='' or @RUC='')
begin
	print 'No pueden ser nulos'
end
else
		begin
			update Productos set NombreProd=@NP,
			PrecioP=@PrecioP, ExistP=@ExistP, RUC=@RUC
			where CodProd=@CodP and EstadoProd=1
	end

-- Procedimiento de Dar baja
create procedure DarBProducto
@CodP char(5)
as
declare @idprod as char(5)
set @idprod=(select CodProd from Productos
where CodProd= @idprod)
if(@CodP= @idprod)
begin
	update Productos set EstadoProd=0 where CodProd=@CodP
end
else
begin
	print 'Producto no encontrado'
end

---Buscar
Create procedure BuscaProduc
@IDP char(5)
as
declare @idPro as char(5)
set @idPro=(select CodProd from Productos where CodProd=@IDP )
if(@IDP ='')
begin
	print 'No pueden ser nulos'
end
else
begin
	if(@IDP=@idPro)
	begin
	select * from Productos where CodProd=@IDP
	end
	else
	begin
		print 'Producto no encontrado'
	end
end

select * from Productos
MostrarProd
---Mostrar productos (Necesario para el datagrid)

----Fijate mejor, por copiar y pegar agragaste "Dirrecion"XD
create proc MostrarProd
as
BEGIN
     select CodProd as ID,NombreProd as Nombre,PrecioP as Precio,ExistP as Existencias,RUC as RUC from Productos where EstadoProd=1
END     

sp_addlogin 'LuisaT', 'IL22', 'SVentas'
sp_addsrvrolemember 'LuisaT', 'sysadmin'
sp_adduser 'LuisaT', 'LuisaT'
sp_addrolemember 'db_ddladmin', 'LuisaT'

--1.2.- Solo lectura
sp_addlogin 'Vendedor','V*123','SVentas'
sp_addsrvrolemember 'Vendedor','processadmin'
use SVentas
sp_adduser 'Vendedor','Vendedor'
sp_addrolemember 'db_denydatawriter','Vendedor'
sp_addrolemember 'db_datareader','Vendedor'

revoke create table, create view, create procedure to
Vendedor

deny insert, delete, update on Clientes to Vendedor
deny insert, delete, update on Compras to Vendedor

--Para usar los reportes
/*
Primero se instala:
Reporting Services
luego el paquete nuget
y se ejecuta en consola el pkt nuget

*/