﻿using ExamenLuisa.Connection_and_Class;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ExamenLuisa
{
    public partial class frmVentas : Form
    {
        public Connection con;
        int renglon;

        public frmVentas(Connection con)
        {
            this.con = con;
            InitializeComponent();
            ListarV();
        }

        private void ListarV()
        {
            con.listarVentas(dgvVent);
        }

        private void dgvVent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvVent.Rows[e.RowIndex];
                //txtCod.Text = row.Cells["ID"].Value.ToString();
                mtbFecha.Text = row.Cells["Fecha"].Value.ToString();
                txtCCli.Text = row.Cells["CodCliente"].Value.ToString();
                txtTotal.Text = row.Cells["TotalV"].Value.ToString();
            }
        }

        private void txtRUC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 32 && e.KeyChar <= 47 || e.KeyChar >= 58 && e.KeyChar <= 255)
            {
                MessageBox.Show("Solo se permiten numeros", "Intentalo, nuevamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                e.Handled = true;
                return;
            }
        }
    }
}
