﻿using ExamenLuisa.Connection_and_Class;
using System;
using System.Windows.Forms;

namespace ExamenLuisa
{
    public partial class frmMenu : Form
    {
        public Connection con;
        public frmMenu(Connection con)
        {
            this.con = con;
            InitializeComponent();
        }


        private void OpenPanel(object FrmSon)
        {
            if (this.pContiene.Controls.Count > 0)
                this.pContiene.Controls.RemoveAt(0);
            Form fh = (Form)FrmSon;
            fh.TopLevel = false;
            fh.Dock = DockStyle.Fill;
            this.pContiene.Controls.Add(fh);
            this.pContiene.Tag = fh;
            fh.Show();
        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenPanel(new frmVentas(con));
        }
    }
}
