﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ExamenLuisa.Connection_and_Class
{
   public class Connection
    {
        public SqlConnection connect = new SqlConnection();
        public Connection(String user, String pass)
        {
            try
            {
                connect = new SqlConnection("Server=SIS10\\SQLSERVER2019;Database=SVentas;UID=" + user + ";PWD=" + pass);
                connect.Open();
            }
            catch (Exception)
            {

                MessageBox.Show("No se puede conectar al servidor!", "Advertencia!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        public void listarVentas(DataGridView GridView1)
        {

            SqlCommand cmd = new SqlCommand();
            //SqlDataReader read;

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "MostrarV";
            cmd.Connection = connect;


            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;

        }



        //Productos
        public void InsertProduct(string cod, string NombreProd, float precio, int exits, string RUC)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();

                SqlParameter[] param = new SqlParameter[5];
                param[0] = new SqlParameter("@CodP", SqlDbType.Char);
                param[0].Value = cod;
                param[1] = new SqlParameter("@NP", SqlDbType.VarChar);
                param[1].Value = NombreProd;
                param[2] = new SqlParameter("@PrecioP", SqlDbType.Money);
                param[2].Value = precio;
                param[3] = new SqlParameter("@ExistP", SqlDbType.VarChar);
                param[3].Value = exits;
                param[4] = new SqlParameter("@RUC", SqlDbType.VarChar);
                param[4].Value = RUC;


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "InsertProduct";
                cmd.Connection = connect;
                cmd.Parameters.AddRange(param);

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(ds);
            }
            catch (Exception)
            {

                MessageBox.Show("Error en la insercion", "Intentalo, nuevamente", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

        }
        public void ModificarPro(string cod, string NombreProd, float precio, int exits, string RUC)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                SqlParameter[] param = new SqlParameter[5];
                param[0] = new SqlParameter("@CodP", SqlDbType.Char);
                param[0].Value = cod;
                param[1] = new SqlParameter("@NP", SqlDbType.VarChar);
                param[1].Value = NombreProd;
                param[2] = new SqlParameter("@PrecioP", SqlDbType.Money);
                param[2].Value = precio;
                param[3] = new SqlParameter("@ExistP", SqlDbType.Int);
                param[3].Value = exits;
                param[4] = new SqlParameter("@RUC", SqlDbType.VarChar);
                param[4].Value = RUC;


                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ModProduct";
                cmd.Connection = connect;
                cmd.Parameters.AddRange(param);

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(ds);
            }
            catch (Exception)
            {

                MessageBox.Show("Error en la modificación", "Intentalo, nuevamente", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

        }

        public void eliminarPro(string cod)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                SqlParameter[] param = new SqlParameter[1];
                param[0] = new SqlParameter("@CodP", SqlDbType.Char);
                param[0].Value = cod;

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "DarBProducto";
                cmd.Connection = connect;
                cmd.Parameters.AddRange(param);

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(ds);
            }
            catch (Exception)
            {

                MessageBox.Show("Error en la eliminación", "Intentalo, nuevamente", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

        }
        public void listarProductos(DataGridView GridView1)
        {

            SqlCommand cmd = new SqlCommand();
            //SqlDataReader read;

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "MostrarProd";
            cmd.Connection = connect;


            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            da.Fill(dt);

            GridView1.DataSource = dt;

        }
        public void BuscarPro(string cod)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                SqlParameter[] param = new SqlParameter[1];
                param[0] = new SqlParameter("@CodP", SqlDbType.Char);
                param[0].Value = cod;

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BuscaProduc";
                cmd.Connection = connect;
                cmd.Parameters.AddRange(param);

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(ds);
            }
            catch (Exception)
            {

                MessageBox.Show("Error en la Busqueda", "Intentalo, nuevamente", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

        }

    }
}
